﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace entidad
{
    public class Baro
    {
        public int CodHorno { get; set; }
        public DateTime FechaHoraSesion { get; set; }
        public int CodDoc { get; set; }
        public int CodPac { get; set; }
        public string Zip { get; set; }
        public string FichaAnagrafica { get; set; }
        public bool Requiere { get; set; }
        public string Monsuracion { get; set; }
        public string Login { get; set; }

 
    }
}
