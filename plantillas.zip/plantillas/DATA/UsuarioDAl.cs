﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using entidad;
namespace DATA
{
    public class UsuarioDAL
    {
        private readonly string _conexion = "Data Source=BARO-1;Initial Catalog=BDPLANT;Integrated Security=True";

        public int Insertar(Usuario usuario)
        {
            using (SqlConnection conn = new SqlConnection(_conexion))
            {
                string sql = "INSERT INTO usuario (usuario) VALUES (@usuario); SELECT SCOPE_IDENTITY();";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@usuario", usuario.NombreUsuario);
                conn.Open();
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        public List<Usuario> ObtenerTodos()
        {
            List<Usuario> lista = new List<Usuario>();
            using (SqlConnection conn = new SqlConnection(_conexion))
            {
                string sql = "SELECT * FROM usuario";
                SqlCommand cmd = new SqlCommand(sql, conn);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    lista.Add(new Usuario
                    {
                        IdUsuario = (int)reader["idusuario"],
                        NombreUsuario = reader["usuario"].ToString()
                    });
                }
            }
            return lista;
        }
    }
}
