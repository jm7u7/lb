﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using entidad;

namespace DATA
{
    public class BaroDAL
    {
        private readonly string _conexion = "Data Source=BARO-1;Initial Catalog=BDPLANT;Integrated Security=True";

        public int Insertar(Baro baro)
        {
            using (SqlConnection conn = new SqlConnection(_conexion))
            {
                string sql = @"INSERT INTO baro 
                               (codhorno, fechahorasesion, coddoc, codpac, zip, fichaanagrafica, requiere, monsuracion, login) 
                               VALUES (@codhorno, @fechahorasesion, @coddoc, @codpac, @zip, @fichaanagrafica, @requiere, @monsuracion, @login)";
                SqlCommand cmd = new SqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@codhorno", baro.CodHorno);
                cmd.Parameters.AddWithValue("@fechahorasesion", baro.FechaHoraSesion);
                cmd.Parameters.AddWithValue("@coddoc", baro.CodDoc);
                cmd.Parameters.AddWithValue("@codpac", baro.CodPac);
                cmd.Parameters.AddWithValue("@zip", baro.Zip);
                cmd.Parameters.AddWithValue("@fichaanagrafica", baro.FichaAnagrafica);
                cmd.Parameters.AddWithValue("@requiere", baro.Requiere);
                cmd.Parameters.AddWithValue("@monsuracion", baro.Monsuracion);
                cmd.Parameters.AddWithValue("@login", baro.Login);

                conn.Open();
                return cmd.ExecuteNonQuery(); // retorna 1 si insertó correctamente
            }
        }

        public List<Baro> ObtenerTodos()
        {
            List<Baro> lista = new List<Baro>();

            using (SqlConnection conn = new SqlConnection(_conexion))
            {
                string sql = @"SELECT b.*, p.nombre AS nombrepaciente
                               FROM baro b
                               INNER JOIN paciente p ON b.codpac = p.codpac";

                SqlCommand cmd = new SqlCommand(sql, conn);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    lista.Add(new Baro
                    {
                        CodHorno = (int)reader["codhorno"],
                        FechaHoraSesion = (DateTime)reader["fechahorasesion"],
                        CodDoc = (int)reader["coddoc"],
                        CodPac = (int)reader["codpac"],
                        Zip = reader["zip"].ToString(),
                        FichaAnagrafica = reader["fichaanagrafica"].ToString(),
                        Requiere = (bool)reader["requiere"],
                        Monsuracion = reader["monsuracion"].ToString(),
                        Login = reader["login"].ToString(),
                        NombrePaciente = reader["nombrepaciente"].ToString()
                    });
                }
            }

            return lista;
        }
    }
}
