﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using entidad;
using System.Data.SqlClient;

namespace DATA
{
    public class LoginDAL
    {
        private readonly string _conexion = "Data Source=BARO-1;Initial Catalog=BDPLANT;Integrated Security=True";

        public int Insertar(Login login)
        {
            using (SqlConnection conn = new SqlConnection(_conexion))
            {
                string sql = "INSERT INTO login (idusuario, idsede) VALUES (@idusuario, @idsede); SELECT SCOPE_IDENTITY();";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@idusuario", login.IdUsuario);
                cmd.Parameters.AddWithValue("@idsede", login.IdSede);
                conn.Open();
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        public List<Login> ObtenerTodos()
        {
            List<Login> lista = new List<Login>();
            using (SqlConnection conn = new SqlConnection(_conexion))
            {
                string sql = "SELECT * FROM login";
                SqlCommand cmd = new SqlCommand(sql, conn);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    lista.Add(new Login
                    {
                        IdLogin = (int)reader["idlogin"],
                        IdUsuario = (int)reader["idusuario"],
                        IdSede = (int)reader["idsede"]
                    });
                }
            }
            return lista;
        }
    }
}
