﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using entidad;

namespace DATA
{
    public class SedeDAL
    {
        private readonly string _conexion = "Data Source=BARO-1;Initial Catalog=BDPLANT;Integrated Security=True";

        public int Insertar(SedeCRM sede)
        {
            using (SqlConnection conn = new SqlConnection(_conexion))
            {
                string sql = "INSERT INTO sedecrm (idsede, sede) VALUES (@idsede, @sede)";
                SqlCommand cmd = new SqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@idsede", sede.IdSede);
                cmd.Parameters.AddWithValue("@sede", sede.Sede);

                conn.Open();
                return cmd.ExecuteNonQuery(); // 1 si se insertó correctamente
            }
        }

        public List<SedeCRM> ObtenerTodas()
        {
            List<SedeCRM> lista = new List<SedeCRM>();

            using (SqlConnection conn = new SqlConnection(_conexion))
            {
                string sql = "SELECT * FROM sedecrm";
                SqlCommand cmd = new SqlCommand(sql, conn);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    lista.Add(new SedeCRM
                    {
                        IdSede = (int)reader["idsede"],
                        Sede = reader["sede"].ToString()
                    });
                }
            }

            return lista;
        }
    }
}
