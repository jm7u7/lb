﻿namespace Logica
{
    public class LoginBLL
    {
        private readonly Login _dal = new Login();

        public int Registrar(Login login)
        {
            return _dal.Insertar(login);
        }

        public List<Login> Listar()
        {
            return _dal.ObtenerTodos();
        }
    }
}
