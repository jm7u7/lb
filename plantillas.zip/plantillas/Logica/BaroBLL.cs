﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using entidad;

namespace Logica
{
    public class BaroBLL
    {
        private readonly BaroBLL _dal = new BaroBLL();

        public int Registrar(Baro baro)
        {
            return _dal.INSERTAR(baro);
        }

        public List<Baro> Listar()
        {
            return _dal.ObtenerTodos();
        }
    }
}
