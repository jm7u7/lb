﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DATA;
using entidad;

namespace Logica
{
    public class SedeBLL
    {
        private readonly SedeDAL _dal = new SedeDAL();

        public int Registrar(SedeCRM sede)
        {
            return _dal.Insertar(sede);
        }

        public List<SedeCRM> Listar()
        {
            return _dal.ObtenerTodas();
        }
    }
}
