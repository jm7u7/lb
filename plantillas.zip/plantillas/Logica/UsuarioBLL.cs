﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DATA;
using entidad;

namespace Logica
{
    public class UsuarioBLL
    {
        private readonly UsuarioDAL dal = new UsuarioDAL();

        public List<Usuario> Listar()
        {
            return _dal.ObtenerTodos();
        }
    }
}
