using System;
using entidad;
using Logica;
namespace Usuario
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
          
            https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Application.Run(new Form1());
        }
    }
}