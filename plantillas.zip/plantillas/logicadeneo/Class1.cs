﻿namespace logicadeneo
{
    public class Class1
    {

    }
}
